# Statement of Applicability (SoA)
**Generated:** 2026-01-15
**Organization:** AssuRisk Demo Corp

## Executive Summary
This document defines the applicability of ISO 27001:2022 controls to our organization.

## Applicability Matrix
| Control ID | Title | Status | Justification |
|---|---|---|---|
| 4.1 | Understanding the organization and its context | Planned | This foundational clause requires the organization... |
| 4.2 | Understanding the needs and expectations of interested parties | Planned | This fundamental governance clause mandates the sy... |
| 4.3 | Determining the scope of the information security management system | Planned | Standard control requirement.... |
| 4.4 | Information security management system | Planned | Standard control requirement.... |
| 5.1 | Leadership and commitment | Planned | Standard control requirement.... |
| 5.2 | Policy | Planned | Standard control requirement.... |
| 5.3 | Organizational roles, responsibilities and authorities | Planned | Standard control requirement.... |
| 6.1.1 | General (Actions to address risks and opportunities) | Planned | This clause mandates that planning for the Informa... |
| 6.1.2 | Information security risk assessment | Planned | Standard control requirement.... |
| 6.1.3 | Information security risk treatment | Planned | Standard control requirement.... |
| 6.2 | Information security objectives and planning to achieve them | Planned | Standard control requirement.... |
| 6.3 | Planning of changes | Planned | Standard control requirement.... |
| 7.1 | Resources | Planned | Standard control requirement.... |
| 7.2 | Competence | Planned | Standard control requirement.... |
| 7.3 | Awareness | Planned | Standard control requirement.... |
| 7.4 | Communication | Planned | Standard control requirement.... |
| 7.5 | Documented information | Planned | Standard control requirement.... |
| 8.1 | Operational planning and control | Planned | Standard control requirement.... |
| 8.2 | Information security risk assessment | Planned | Standard control requirement.... |
| 8.3 | Information security risk treatment | Planned | This critical operational phase requires the organ... |
| 9.1 | Monitoring, measurement, analysis and evaluation | Planned | Standard control requirement.... |
| 9.2 | Internal audit | Planned | This clause mandates that the organization establi... |
| 9.3 | Management review | Planned | Standard control requirement.... |
| 10.1 | Continual improvement | Planned | Standard control requirement.... |
| 10.2 | Nonconformity and corrective action | Planned | Standard control requirement.... |
| A.5.1 | Policies for information security | Planned | Standard control requirement.... |
| A.5.2 | Information security roles and responsibilities | Planned | Standard control requirement.... |
| A.5.3 | Segregation of duties | Planned | Standard control requirement.... |
| A.5.4 | Management responsibilities | Planned | Standard control requirement.... |
| A.5.5 | Contact with authorities | Planned | Standard control requirement.... |
| A.5.6 | Contact with special interest groups | Planned | Standard control requirement.... |
| A.5.7 | Threat intelligence | Planned | Standard control requirement.... |
| A.5.8 | Information security in project management | Planned | Standard control requirement.... |
| A.5.9 | Inventory of information and other associated assets | Planned | Standard control requirement.... |
| A.5.10 | Acceptable use of information and other associated assets | Planned | Standard control requirement.... |
| A.5.11 | Return of assets | Planned | Standard control requirement.... |
| A.5.12 | Classification of information | Planned | Standard control requirement.... |
| A.5.13 | Labelling of information | Planned | Standard control requirement.... |
| A.5.14 | Information transfer | Planned | Standard control requirement.... |
| A.5.15 | Access control | Planned | Standard control requirement.... |
| A.5.16 | Identity management | Planned | Standard control requirement.... |
| A.5.17 | Authentication information | Planned | Standard control requirement.... |
| A.5.18 | Access rights | Planned | Standard control requirement.... |
| A.5.19 | Information security in supplier relationships | Planned | Standard control requirement.... |
| A.5.20 | Addressing information security within supplier agreements | Planned | Standard control requirement.... |
| A.5.21 | Managing information security in the ICT supply chain | Planned | Standard control requirement.... |
| A.5.22 | Monitoring, review and change management of supplier services | Planned | Standard control requirement.... |
| A.5.23 | Information security for use of cloud services | Planned | Standard control requirement.... |
| A.5.24 | Information security incident management planning and preparation | Planned | Standard control requirement.... |
| A.5.25 | Assessment and decision on information security events | Planned | Standard control requirement.... |
| A.5.26 | Response to information security incidents | Planned | Standard control requirement.... |
| A.5.27 | Learning from information security incidents | Planned | Standard control requirement.... |
| A.5.28 | Collection of evidence | Planned | Standard control requirement.... |
| A.5.29 | Information security during disruption | Planned | Standard control requirement.... |
| A.5.30 | ICT readiness for business continuity | Planned | Standard control requirement.... |
| A.5.31 | Legal, statutory, regulatory and contractual requirements | Planned | Standard control requirement.... |
| A.5.32 | Intellectual property rights | Planned | Standard control requirement.... |
| A.5.33 | Protection of records | Planned | Standard control requirement.... |
| A.5.34 | Privacy and protection of PII | Planned | Standard control requirement.... |
| A.5.35 | Independent review of information security | Planned | Standard control requirement.... |
| A.5.36 | Compliance with policies, rules and standards for information security | Planned | Standard control requirement.... |
| A.5.37 | Documented operating procedures | Planned | Standard control requirement.... |
| A.6.1 | Screening | Planned | Standard control requirement.... |
| A.6.2 | Terms and conditions of employment | Planned | Standard control requirement.... |
| A.6.3 | Information security awareness, education and training | Planned | Standard control requirement.... |
| A.6.4 | Disciplinary process | Planned | Standard control requirement.... |
| A.6.5 | Responsibilities after termination or change of employment | Planned | Standard control requirement.... |
| A.6.6 | Confidentiality or non-disclosure agreements | Planned | Standard control requirement.... |
| A.6.7 | Remote working | Planned | Standard control requirement.... |
| A.6.8 | Information security event reporting | Planned | Standard control requirement.... |
| A.7.1 | Physical security perimeters | Planned | Standard control requirement.... |
| A.7.2 | Physical entry | Planned | Standard control requirement.... |
| A.7.3 | Securing offices, rooms and facilities | Planned | Standard control requirement.... |
| A.7.4 | Physical security monitoring | Planned | Standard control requirement.... |
| A.7.5 | Protecting against physical and environmental threats | Planned | Standard control requirement.... |
| A.7.6 | Working in secure areas | Planned | Standard control requirement.... |
| A.7.7 | Clear desk and clear screen | Planned | Standard control requirement.... |
| A.7.8 | Equipment siting and protection | Planned | Standard control requirement.... |
| A.7.9 | Security of assets off-premises | Planned | Standard control requirement.... |
| A.7.10 | Storage media | Planned | Standard control requirement.... |
| A.7.11 | Supporting utilities | Planned | Standard control requirement.... |
| A.7.12 | Cabling security | Planned | Standard control requirement.... |
| A.7.13 | Equipment maintenance | Planned | Standard control requirement.... |
| A.7.14 | Secure disposal or re-use of equipment | Planned | Standard control requirement.... |
| A.8.1 | User endpoint devices | Planned | Standard control requirement.... |
| A.8.2 | Privileged access rights | Planned | Standard control requirement.... |
| A.8.3 | Information access restriction | Planned | Standard control requirement.... |
| A.8.4 | Access to source code | Planned | Standard control requirement.... |
| A.8.5 | Secure authentication | Planned | Standard control requirement.... |
| A.8.6 | Capacity management | Planned | Standard control requirement.... |
| A.8.7 | Protection against malware | Planned | Standard control requirement.... |
| A.8.8 | Management of technical vulnerabilities | Planned | Standard control requirement.... |
| A.8.9 | Configuration management | Planned | Standard control requirement.... |
| A.8.10 | Information deletion | Planned | Standard control requirement.... |
| A.8.11 | Data masking | Planned | Standard control requirement.... |
| A.8.12 | Data leakage prevention | Planned | Standard control requirement.... |
| A.8.13 | Information backup | Planned | Standard control requirement.... |
| A.8.14 | Redundancy of information processing facilities | Planned | Standard control requirement.... |
| A.8.15 | Logging | Planned | Standard control requirement.... |
| A.8.16 | Monitoring activities | Planned | Standard control requirement.... |
| A.8.17 | Clock synchronization | Planned | Standard control requirement.... |
| A.8.18 | Use of privileged utility programs | Planned | Standard control requirement.... |
| A.8.20 | Networks security | Planned | Standard control requirement.... |
| A.8.21 | Security of network services | Planned | Standard control requirement.... |
| A.8.22 | Segregation of networks | Planned | Standard control requirement.... |
| A.8.23 | Web filtering | Planned | Standard control requirement.... |
| A.8.24 | Use of cryptography | Planned | Standard control requirement.... |
| A.8.25 | Secure development life cycle | Planned | Standard control requirement.... |
| A.8.26 | Application security requirements | Planned | Standard control requirement.... |
| A.8.27 | Secure system architecture and engineering principles | Planned | Standard control requirement.... |
| A.8.28 | Secure coding | Planned | Standard control requirement.... |
| A.8.29 | Security testing in development and acceptance | Planned | Standard control requirement.... |
| A.8.30 | Outsourced development | Planned | Standard control requirement.... |
| A.8.31 | Separation of development, test and production environments | Planned | Standard control requirement.... |
| A.8.32 | Change management | Planned | Standard control requirement.... |
| A.8.33 | Test information | Planned | Standard control requirement.... |
| A.8.34 | Protection of information systems during audit testing | Planned | Standard control requirement.... |
| A.8.19 | Installation of software on operational systems | Planned | Standard control requirement.... |
| CC1.1 | Tone at the Top | Planned | Standard control requirement.... |
| CC1.2 | Board Oversight | Planned | Standard control requirement.... |
| CC2.1 | Internal Communication | Planned | Standard control requirement.... |
| CC3.1 | Risk Mitigation | Planned | Standard control requirement.... |
| CC4.1 | Evaluation of Controls | Planned | Standard control requirement.... |
| CC5.1 | Deficiency Evaluation | Planned | Standard control requirement.... |
| CC6.1 | Logical Access Security | Planned | Standard control requirement.... |
| CC6.2 | User Provisioning | Planned | Standard control requirement.... |
| CC6.3 | Least Privilege Access | Planned | Standard control requirement.... |
| CC7.1 | System Monitoring | Planned | Standard control requirement.... |
| CC8.1 | Change Management | Planned | Standard control requirement.... |
| A1.1 | Capacity Management | Planned | Standard control requirement.... |
| A1.2 | Environmental Protections | Planned | Standard control requirement.... |
| A1.3 | Data Backup & Recovery | Planned | Standard control requirement.... |
| C1.1 | Confidentiality of Information | Planned | Standard control requirement.... |
| C1.2 | Disposal of Confidential Info | Planned | Standard control requirement.... |
| P1.0 | Privacy Notice | Planned | Standard control requirement.... |
| P2.1 | Choice and Consent | Planned | Standard control requirement.... |
| ACCESS-CON | Access Control: Unique User Identification | Planned | Standard control requirement.... |
| P3.1 | Collection Limitation | Planned | Standard control requirement.... |
| AUDIT-CONT | Audit Controls: Review Records of Activity | Planned | Standard control requirement.... |
| P5.0 | Access to Personal Info | Planned | Standard control requirement.... |
| PERSON-OR- | Person or Entity Authentication | Planned | Standard control requirement.... |
| INSTALL-AN | Install and Maintain Network Security Controls | Planned | Standard control requirement.... |
| PROTECT-ST | Protect Stored Account Data | Planned | Standard control requirement.... |
| ENCRYPT-CA | Encrypt Cardholder Data Across Open/Public Networks | Planned | Standard control requirement.... |
| CONDITIONS | Conditions for collection and processing | Planned | Standard control requirement.... |
| OBLIGATION | Obligations to PII principals | Planned | Standard control requirement.... |
| PRIVACY-BY | Privacy by design and privacy by default | Planned | Standard control requirement.... |
| AI-RISK-AS | AI Risk Assessment | Planned | Standard control requirement.... |
| AI-SYSTEM- | AI System Impact Assessment | Planned | Standard control requirement.... |
| DATA-QUALI | Data Quality and Management for AI | Planned | Standard control requirement.... |
| LAWFULNESS | Lawfulness of processing | Planned | Standard control requirement.... |
| RIGHT-TO-E | Right to erasure ('right to be forgotten') | Planned | Standard control requirement.... |
| DATA-PROTE | Data protection impact assessment | Planned | Standard control requirement.... |
| CONSUMER-R | Consumer Right to Know | Planned | Standard control requirement.... |
| DO-NOT-SEL | Do Not Sell My Personal Information | Planned | Standard control requirement.... |
| AC-1-ACCES | AC-1 Access Control Policy and Procedures | Planned | Standard control requirement.... |
| AU-2-AUDIT | AU-2 Audit Events | Planned | Standard control requirement.... |
| IR-4-INCID | IR-4 Incident Handling | Planned | Standard control requirement.... |
| GV.OC-01- | GV.OC-01: Organizational Context | Planned | Standard control requirement.... |
| ID.AM-01- | ID.AM-01: Inventories of Hardware Managed | Planned | Standard control requirement.... |
| PR.AA-01- | PR.AA-01: Identity Management and Authentication | Planned | Standard control requirement.... |